from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path
from functools import lru_cache

import numpy as np
import pandas as pd
import yaml

from alpha_tracker2.scoring.base import Scorer
from alpha_tracker2.scoring.thresholds import ThresholdConfig, get_threshold


def _z(s: pd.Series) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").astype(float)
    mu = s.mean()
    sd = s.std(ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(s)), index=s.index, dtype=float)
    return (s - mu) / sd


@dataclass
class CommonCfg:
    q: float = 0.9
    window: int = 60
    topk_fallback: int = 50  # 若过滤后为空，则保留 topK 兜底（避免全空）


def _find_project_root(start: Path) -> Path | None:
    """
    向上寻找包含 configs/default.yaml 的项目根目录。
    这样无论从哪里调用 scorer，都能读到同一份配置。
    """
    for p in [start, *start.parents]:
        if (p / "configs" / "default.yaml").exists():
            return p
    return None


@lru_cache(maxsize=1)
def _load_cfg_dict() -> dict:
    root = _find_project_root(Path(__file__).resolve())
    if root is None:
        return {}
    cfg_path = root / "configs" / "default.yaml"
    try:
        return yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    except Exception:
        # 配置读取失败时，不影响主流程：直接回退到代码默认值
        return {}


def _cfg_from_yaml(version: str) -> CommonCfg:
    """
    从 default.yaml 读取 scoring.v2_v3_v4.common（可选）。
    如果不存在/字段不全，回退到默认 CommonCfg。
    """
    cfg = _load_cfg_dict()
    scoring = cfg.get("scoring", {}) if isinstance(cfg, dict) else {}
    block = scoring.get("v2_v3_v4", {})

    # 支持两种写法：
    # scoring.v2_v3_v4.common.{q,window,topk_fallback}
    # 或者老写法直接 scoring.v2_v3_v4.{q,window,topk_fallback}
    if isinstance(block, dict) and "common" in block and isinstance(block["common"], dict):
        common = block.get("common", {})
    else:
        common = block if isinstance(block, dict) else {}

    # 目前先做 common（不做 per_version），但这里留口子不影响未来扩展
    merged = dict(common)

    out = CommonCfg()
    if "q" in merged:
        try:
            out.q = float(merged["q"])
        except Exception:
            pass
    if "window" in merged:
        try:
            out.window = int(merged["window"])
        except Exception:
            pass
    if "topk_fallback" in merged:
        try:
            out.topk_fallback = int(merged["topk_fallback"])
        except Exception:
            pass

    # 简单兜底：防止写成负数/0
    if not (0.0 < out.q < 1.0):
        out.q = 0.9
    if out.window <= 0:
        out.window = 60
    if out.topk_fallback <= 0:
        out.topk_fallback = 50

    return out


class V2TrendScorer(Scorer):
    def __init__(self, hist_path: Path, cfg: CommonCfg | None = None):
        self.hist_path = hist_path
        self.cfg = cfg or _cfg_from_yaml("V2") or CommonCfg()

    def score(self, features: pd.DataFrame, trade_date: date) -> pd.DataFrame:
        df = features.copy()
        df["ret_z"] = _z(df["ret_1d"])
        df["mom_z"] = _z(df["mom_5d"])
        df["score"] = 0.3 * df["ret_z"] + 0.7 * df["mom_z"]

        thr = get_threshold(self.hist_path, "V2", cfg=ThresholdConfig(q=self.cfg.q, window=self.cfg.window))
        df["pass_thr"] = df["score"] >= thr

        out = df.sort_values("score", ascending=False).reset_index(drop=True)
        picked = out[out["pass_thr"]].copy()

        if picked.empty:
            picked = out.head(self.cfg.topk_fallback).copy()
            reason_thr = f"(fallback top{self.cfg.topk_fallback}; hist_thr={thr:.4f})"
        else:
            reason_thr = f"(hist_thr={thr:.4f})"

        picked["rank"] = range(1, len(picked) + 1)
        picked["reason"] = f"V2 trend: 0.7*mom_z + 0.3*ret_z {reason_thr}"

        if "name" not in picked.columns:
            picked["name"] = None

        return picked[["ticker", "name", "rank", "score", "reason"]]


class V3LowVolScorer(Scorer):
    def __init__(self, hist_path: Path, cfg: CommonCfg | None = None):
        self.hist_path = hist_path
        self.cfg = cfg or _cfg_from_yaml("V3") or CommonCfg()

    def score(self, features: pd.DataFrame, trade_date: date) -> pd.DataFrame:
        df = features.copy()
        df["vol_z"] = _z(df["vol_5d"])
        df["score"] = -df["vol_z"]  # 低波更高分

        thr = get_threshold(self.hist_path, "V3", cfg=ThresholdConfig(q=self.cfg.q, window=self.cfg.window))
        df["pass_thr"] = df["score"] >= thr

        out = df.sort_values("score", ascending=False).reset_index(drop=True)
        picked = out[out["pass_thr"]].copy()

        if picked.empty:
            picked = out.head(self.cfg.topk_fallback).copy()
            reason_thr = f"(fallback top{self.cfg.topk_fallback}; hist_thr={thr:.4f})"
        else:
            reason_thr = f"(hist_thr={thr:.4f})"

        picked["rank"] = range(1, len(picked) + 1)
        picked["reason"] = f"V3 low-vol: score=-vol_z {reason_thr}"

        if "name" not in picked.columns:
            picked["name"] = None

        return picked[["ticker", "name", "rank", "score", "reason"]]


class V4TrendMAScorer(Scorer):
    def __init__(self, hist_path: Path, cfg: CommonCfg | None = None):
        self.hist_path = hist_path
        self.cfg = cfg or _cfg_from_yaml("V4") or CommonCfg()

    def score(self, features: pd.DataFrame, trade_date: date) -> pd.DataFrame:
        df = features.copy()
        df["ret_z"] = _z(df["ret_1d"])
        df["mom_z"] = _z(df["mom_5d"])
        df["ma_z"] = _z(df["ma_5"])
        df["ma_sig_z"] = _z(df["ret_z"] - df["ma_z"])

        df["score"] = 0.3 * df["ret_z"] + 0.5 * df["mom_z"] + 0.2 * df["ma_sig_z"]

        thr = get_threshold(self.hist_path, "V4", cfg=ThresholdConfig(q=self.cfg.q, window=self.cfg.window))
        df["pass_thr"] = df["score"] >= thr

        out = df.sort_values("score", ascending=False).reset_index(drop=True)
        picked = out[out["pass_thr"]].copy()

        if picked.empty:
            picked = out.head(self.cfg.topk_fallback).copy()
            reason_thr = f"(fallback top{self.cfg.topk_fallback}; hist_thr={thr:.4f})"
        else:
            reason_thr = f"(hist_thr={thr:.4f})"

        picked["rank"] = range(1, len(picked) + 1)
        picked["reason"] = f"V4 trend+ma: 0.5*mom_z + 0.3*ret_z + 0.2*ma_sig_z {reason_thr}"

        if "name" not in picked.columns:
            picked["name"] = None

        return picked[["ticker", "name", "rank", "score", "reason"]]
