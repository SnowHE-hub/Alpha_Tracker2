from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd

from alpha_tracker2.core.config import load_settings
from alpha_tracker2.storage.duckdb_store import DuckDBStore


ROOT = Path(__file__).resolve().parents[3]


def _parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def _get_trading_days(store: DuckDBStore, start: date, end: date) -> List[date]:
    rows = store.fetchall(
        """
        SELECT DISTINCT trade_date
        FROM prices_daily
        WHERE trade_date BETWEEN ? AND ?
        ORDER BY trade_date
        """,
        (start, end),
    )
    return [r[0] for r in rows]


def _ensure_positions_daily_schema(con) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS positions_daily (
          asof_date DATE,
          version VARCHAR,
          ticker VARCHAR,
          shares BIGINT,
          cash DOUBLE
        );
        """
    )
    con.execute("ALTER TABLE positions_daily ADD COLUMN IF NOT EXISTS asof_date DATE;")
    con.execute("ALTER TABLE positions_daily ADD COLUMN IF NOT EXISTS version VARCHAR;")
    con.execute("ALTER TABLE positions_daily ADD COLUMN IF NOT EXISTS ticker VARCHAR;")
    con.execute("ALTER TABLE positions_daily ADD COLUMN IF NOT EXISTS shares BIGINT;")
    con.execute("ALTER TABLE positions_daily ADD COLUMN IF NOT EXISTS cash DOUBLE;")


def _ensure_trades_schema(con) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS trades_daily (
          trade_date DATE,
          version VARCHAR,
          ticker VARCHAR,
          side VARCHAR,
          shares BIGINT,
          price DOUBLE,
          notional DOUBLE
        );
        """
    )
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS trade_date DATE;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS version VARCHAR;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS ticker VARCHAR;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS side VARCHAR;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS shares BIGINT;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS price DOUBLE;")
    con.execute("ALTER TABLE trades_daily ADD COLUMN IF NOT EXISTS notional DOUBLE;")


def _latest_positions_asof(con, version: str, asof_date: date) -> Tuple[Dict[str, int], float]:
    rows = con.execute(
        """
        SELECT ticker, shares, cash
        FROM positions_daily
        WHERE version = ?
          AND asof_date = (
            SELECT MAX(asof_date)
            FROM positions_daily
            WHERE version = ? AND asof_date <= ?
          )
        """,
        (version, version, asof_date),
    ).fetchall()

    if not rows:
        return {}, 0.0

    hold: Dict[str, int] = {}
    cash = 0.0
    for tk, sh, c in rows:
        if tk is None:
            continue
        tks = str(tk)
        if tks not in ("__CASH__", ""):
            hold[tks] = int(sh or 0)
        if c is not None:
            cash = float(c)

    hold = {k: v for k, v in hold.items() if v > 0}
    return hold, cash


def _load_signal(store: DuckDBStore, signal_date: date, version: str, topk: int) -> List[str]:
    rows = store.fetchall(
        """
        SELECT ticker
        FROM picks_daily
        WHERE trade_date = ? AND version = ?
        ORDER BY
          CASE WHEN rank IS NULL THEN 1 ELSE 0 END ASC,
          rank ASC,
          score DESC NULLS LAST
        LIMIT ?
        """,
        (signal_date, version, topk),
    )
    return [str(r[0]) for r in rows]


def _load_close(store: DuckDBStore, trade_date: date, tickers: List[str]) -> Dict[str, float]:
    if not tickers:
        return {}
    rows = store.fetchall(
        """
        SELECT ticker, close
        FROM prices_daily
        WHERE trade_date = ?
          AND ticker = ANY(?)
        """,
        (trade_date, tickers),
    )
    return {str(t): float(c) for t, c in rows if c is not None and float(c) > 0}


def _equal_weight_target_alloc(equity: float, tickers: List[str], px: Dict[str, float], lot_size: int) -> Dict[str, int]:
    tickers = [t for t in tickers if t in px and px[t] > 0]
    if not tickers:
        return {}
    w = 1.0 / len(tickers)
    target: Dict[str, int] = {}
    for t in tickers:
        budget = equity * w
        shares = int(budget // (px[t] * lot_size)) * lot_size
        if shares > 0:
            target[t] = shares
    return target


def _diff_to_trades(prev: Dict[str, int], target: Dict[str, int]) -> List[Dict]:
    keys = set(prev.keys()) | set(target.keys())
    out = []
    for tk in sorted(keys):
        a = int(prev.get(tk, 0))
        b = int(target.get(tk, 0))
        d = b - a
        if d == 0:
            continue
        out.append({"ticker": tk, "side": "BUY" if d > 0 else "SELL", "shares": abs(d)})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--version", required=True, help="e.g. ENS")
    ap.add_argument("--topk", type=int, default=3)
    ap.add_argument("--cash", type=float, default=100000.0)
    ap.add_argument("--lot_size", type=int, default=100)
    ap.add_argument("--hold_last_signal", action="store_true", help="if set: reuse last non-empty signal on empty days")
    args = ap.parse_args()

    start = _parse_date(args.start)
    end = _parse_date(args.end)
    version = args.version.strip()
    topk = int(args.topk)
    cash0 = float(args.cash)
    lot_size = int(args.lot_size)
    hold_last_signal = bool(args.hold_last_signal)

    print("[OK] execute_rebalance_range started.")
    print("range:", start, "to", end)
    print("version:", version, "topk:", topk, "cash:", cash0, "lot_size:", lot_size)
    print("hold_last_signal:", hold_last_signal)

    cfg = load_settings(ROOT)
    store = DuckDBStore(cfg.store_db, ROOT / "src" / "alpha_tracker2" / "storage" / "schema.sql")
    store.init_schema()

    days = _get_trading_days(store, start, end)
    if not days:
        print("[SKIP] no trading days in range.")
        return

    with store.session() as con:
        _ensure_positions_daily_schema(con)
        _ensure_trades_schema(con)

        # 清理本次区间旧结果，避免累积导致奇怪对比
        con.execute("DELETE FROM trades_daily WHERE trade_date BETWEEN ? AND ? AND version = ?", (start, end, version))
        con.execute("DELETE FROM positions_daily WHERE asof_date BETWEEN ? AND ? AND version = ?", (start, end, version))

        # 初始状态：如果之前已有仓位就接着跑，否则从现金开始
        hold, cash = _latest_positions_asof(con, version, start)
        if not hold and cash == 0.0:
            cash = cash0

        last_signal: List[str] = []          # 上一次“非空原始信号”
        last_effective: List[str] = []       # 上一次“实际使用的信号”(考虑 hold_last)

        n_rebalances = 0

        for d in days:
            raw_signal = _load_signal(store, d, version, topk)

            if raw_signal:
                last_signal = raw_signal

            # effective signal（决定今天要不要调仓）
            if raw_signal:
                eff_signal = raw_signal
            else:
                eff_signal = last_signal if hold_last_signal else []

            # 是否需要调仓：只有当 eff_signal 发生变化才调仓
            need_rebalance = (eff_signal != last_effective)

            # 取价格：调仓/估值都需要（但不做“每天再平衡”）
            need_px_tickers = list(set(list(hold.keys()) + eff_signal))
            px = _load_close(store, d, need_px_tickers)

            if need_rebalance:
                # 计算当日收盘总权益（用于一次性定仓）
                mv = sum(px.get(tk, 0.0) * sh for tk, sh in hold.items() if tk in px)
                equity = cash + mv

                target = _equal_weight_target_alloc(equity, eff_signal, px, lot_size)
                trades = _diff_to_trades(hold, target)

                for tr in trades:
                    tk = tr["ticker"]
                    p = px.get(tk)
                    if p is None or p <= 0:
                        continue

                    sh = int(tr["shares"])
                    notional = float(sh) * float(p)

                    if tr["side"] == "BUY":
                        if notional > cash:
                            # 现金不足就按 lot_size 向下取整
                            sh2 = int((cash // (p * lot_size)) * lot_size)
                            if sh2 <= 0:
                                continue
                            sh = sh2
                            notional = float(sh) * float(p)

                        cash -= notional
                        hold[tk] = int(hold.get(tk, 0)) + sh
                    else:
                        have = int(hold.get(tk, 0))
                        sh = min(sh, have)
                        if sh <= 0:
                            continue
                        notional = float(sh) * float(p)
                        cash += notional
                        new_sh = have - sh
                        if new_sh <= 0:
                            hold.pop(tk, None)
                        else:
                            hold[tk] = new_sh

                    con.execute(
                        """
                        INSERT INTO trades_daily(trade_date, version, ticker, side, shares, price, notional)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (d, version, tk, tr["side"], int(sh), float(p), float(notional)),
                    )

                n_rebalances += 1
                last_effective = eff_signal

            # 每天都写 positions 快照（即使今天不调仓，也把“持有状态”写进去）
            rows = [(d, version, tk, int(sh), float(cash)) for tk, sh in hold.items() if int(sh) > 0]
            if not rows:
                rows = [(d, version, "__CASH__", 0, float(cash))]

            con.executemany(
                "INSERT INTO positions_daily(asof_date, version, ticker, shares, cash) VALUES (?, ?, ?, ?, ?)",
                rows,
            )

    print("[OK] execute_rebalance_range passed.")
    print("days_written:", len(days), "rebalances:", n_rebalances)
    print("last_cash:", round(cash, 2), "n_positions:", len([k for k in hold.keys() if hold[k] > 0]))

    out_dir = ROOT / "data" / "out"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"rebalance_range_{version}_{start}_{end}.csv"
    pd.DataFrame(
        [{
            "version": version,
            "start": str(start),
            "end": str(end),
            "days": len(days),
            "rebalances": n_rebalances,
            "cash_left": float(cash),
        }]
    ).to_csv(out_path, index=False, encoding="utf-8-sig")
    print("[OK] summary exported:", out_path)


if __name__ == "__main__":
    main()
